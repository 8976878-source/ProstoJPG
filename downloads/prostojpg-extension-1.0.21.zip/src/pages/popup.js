import { convertViaServer, fetchRemoteConfig } from "../lib/api.js";
import { mountMessageSlot } from "../lib/message-slot.js";
import { blobToDataUrl, convertBlob, replaceExtension, requiresServerConversion } from "../lib/conversion.js";
import { getSettings, saveSettings } from "../lib/settings.js";
import { bindDesignScreen } from './design.js';

const FORMATS = ["jpg", "png", "gif", "tiff"];
const LAST_POPUP_VIEW_KEY = "prostojpg:lastPopupView";
const ARTICLE_POPUP_PLACEMENT = "popup-article";
const BULK_INPUT_LIMIT = 100;
const DOWNLOAD_PROGRESS_PHRASES = [
  "Скачиваем в хорошем качестве, потерпите.",
  "Скачиваем видео и фото из карточки…",
  "Еще чуть-чуть…",
  "Конвертируем всё в понятный формат JPG и MP4…",
  "Собираем аккуратный архив…"
];

const state = {
  files: [],
  format: "jpg",
  quality: 80,
  converting: false,
  selectedFormat: "jpg",
  currentView: "main",
  bulkRunning: false,
  bulkExpanded: true
};

const elements = {
  mainScreen: document.getElementById("popup-main-screen"),
  settingsScreen: document.getElementById("popup-settings-screen"),
  sellerToolsScreen: document.getElementById("popup-seller-tools-screen"),
  bulkToolScreen: document.getElementById("popup-bulk-tool-screen"),
  helpScreen: document.getElementById("popup-help-screen"),
  designScreen: document.getElementById('popup-design-screen'),
  openHelp: document.getElementById("open-help"),
  backFromHelp: document.getElementById("back-from-help"),
  closeHelpPopup: document.getElementById("close-help-popup"),
  fileInput: document.getElementById("file-input"),
  pickFiles: document.getElementById("pick-files"),
  dropzone: document.getElementById("dropzone"),
  formatButtons: document.getElementById("format-buttons"),
  qualitySlider: document.getElementById("quality-slider"),
  qualityLabel: document.getElementById("quality-label"),
  convertAll: document.getElementById("convert-all"),
  cancelFiles: document.getElementById("cancel-files"),
  fileMeta: document.getElementById("file-meta"),
  status: document.getElementById("status"),
  messagePanel: document.getElementById("message-panel"),
  messageSlot: document.getElementById("message-slot"),
  openSettings: document.getElementById("open-settings"),
  openSellerTools: document.getElementById("open-seller-tools"),
  backFromSellerTools: document.getElementById("back-from-seller-tools"),
  closeSellerToolsPopup: document.getElementById("close-seller-tools-popup"),
  openBulkTool: document.getElementById("open-bulk-tool"),
  backFromBulkTool: document.getElementById("back-from-bulk-tool"),
  closeBulkToolPopup: document.getElementById("close-bulk-tool-popup"),
  backToMain: document.getElementById("back-to-main"),
  closePopup: document.getElementById("close-popup"),
  closeSettingsPopup: document.getElementById("close-settings-popup"),
  saveFolder: document.getElementById("save-folder"),
  settingsQuality: document.getElementById("settings-quality"),
  settingsQualityLabel: document.getElementById("settings-quality-label"),
  settingsFormatButtons: document.getElementById("settings-format-buttons"),
  autoConvertOnDownload: document.getElementById("autoConvertOnDownload"),
  saveSettings: document.getElementById("save-settings"),
  cancelSettings: document.getElementById("cancel-settings"),
  saveStatus: document.getElementById("save-status"),
  bulkSessionMini: document.getElementById("bulk-session-mini"),
  bulkControls: document.getElementById("bulk-controls"),
  bulkMarketOzon: document.getElementById("bulk-market-ozon"),
  bulkMarketWb: document.getElementById("bulk-market-wb"),
  bulkSkus: document.getElementById("bulk-skus"),
  bulkStart: document.getElementById("bulk-start"),
  bulkResults: document.getElementById("bulk-results"),
  bulkOverlay: document.getElementById("bulk-overlay"),
  bulkOverlaySubtitle: document.getElementById("bulk-overlay-subtitle"),
  bulkOverlayPhrase: document.getElementById("bulk-overlay-phrase"),
  bulkOverlayTasks: document.getElementById("bulk-overlay-tasks"),
  bulkOverlayLineBar: document.getElementById("bulk-overlay-line-bar"),
  bulkOverlayCreative: document.getElementById("bulk-overlay-creative"),
  bulkOverlayCreativeSlot: document.getElementById("bulk-overlay-creative-slot"),
  bulkStop: document.getElementById("bulk-stop")
};

bootstrap();

async function bootstrap() {
  const settings = await getSettings();
  applyConversionSettings(settings);
  applySettingsForm(settings);
  bindPopupEvents();
  bindDesignScreen(switchView);
  updateFilesMeta();
  updateActionButtons();
  await initBulkDownloader();
  await loadMessage();
  const lastView = await getLastPopupView();
  switchView(lastView || "main", { persist: false });
}

function bindPopupEvents() {
  if (elements.pickFiles && elements.fileInput) {
    elements.pickFiles.addEventListener("click", () => elements.fileInput.click());
  }

  if (elements.fileInput) {
    elements.fileInput.addEventListener("change", (event) => {
      addFiles(event.target.files);
      elements.fileInput.value = "";
    });
  }

  if (elements.qualitySlider && elements.qualityLabel) {
    elements.qualitySlider.addEventListener("input", (event) => {
      state.quality = Number(event.target.value);
      elements.qualityLabel.textContent = `Качество: ${state.quality}%`;
    });
  }

  if (elements.convertAll) {
    elements.convertAll.addEventListener("click", convertAllFiles);
  }

  if (elements.cancelFiles) {
    elements.cancelFiles.addEventListener("click", () => {
      state.files = [];
      setStatus("");
      updateFilesMeta();
      updateActionButtons();
    });
  }

  if (elements.openSettings) {
    elements.openSettings.addEventListener("click", async () => {
      const settings = await getSettings();
      applySettingsForm(settings);
      setSaveStatus("");
      switchView("settings");
    });
  }

  elements.openSellerTools?.addEventListener("click", () => switchView("seller-tools"));
  elements.backFromSellerTools?.addEventListener("click", () => switchView("main"));
  elements.closeSellerToolsPopup?.addEventListener("click", () => window.close());
  elements.openBulkTool?.addEventListener("click", () => switchView("bulk-tool"));
  elements.backFromBulkTool?.addEventListener("click", () => switchView("seller-tools"));
  elements.closeBulkToolPopup?.addEventListener("click", () => window.close());
  elements.openHelp?.addEventListener("click", () => switchView("help"));
  elements.backFromHelp?.addEventListener("click", () => switchView("seller-tools"));
  elements.closeHelpPopup?.addEventListener("click", () => window.close());

  if (elements.backToMain) {
    elements.backToMain.addEventListener("click", () => {
      setSaveStatus("");
      switchView("main");
    });
  }

  if (elements.closePopup) {
    elements.closePopup.addEventListener("click", () => window.close());
  }

  if (elements.closeSettingsPopup) {
    elements.closeSettingsPopup.addEventListener("click", () => window.close());
  }

  if (elements.settingsQuality && elements.settingsQualityLabel) {
    elements.settingsQuality.addEventListener("input", () => {
      elements.settingsQualityLabel.textContent = `Качество по умолчанию: ${elements.settingsQuality.value}%`;
    });
  }

  if (elements.saveSettings) {
    elements.saveSettings.addEventListener("click", onSaveSettings);
  }

  if (elements.cancelSettings) {
    elements.cancelSettings.addEventListener("click", async () => {
      const settings = await getSettings();
      applySettingsForm(settings);
      setSaveStatus("Изменения сброшены.");
    });
  }

  wireDropzone();
  wireBulkDownloader();
}

const CARET_DOWN_ICON = `<svg viewBox="0 0 256 256" aria-hidden="true"><polyline points="208 96 128 176 48 96" fill="none" stroke="currentColor" stroke-linecap="round" stroke-linejoin="round" stroke-width="24" /></svg>`;
const CARET_UP_ICON = `<svg viewBox="0 0 256 256" aria-hidden="true"><polyline points="48 160 128 80 208 160" fill="none" stroke="currentColor" stroke-linecap="round" stroke-linejoin="round" stroke-width="24" /></svg>`;

async function initBulkDownloader() {
  state.bulkExpanded = true;
  renderBulkControls();
  await loadBulkOverlayCreative();
  await refreshBulkSession();
}

function wireBulkDownloader() {
  wireMarketplaceSingleChoice();
  elements.bulkStart?.addEventListener("click", startBulkDownload);
  elements.bulkStop?.addEventListener("click", stopBulkDownload);

  chrome.runtime.onMessage.addListener((message) => {
    if (message?.type === "BULK_DOWNLOAD_PROGRESS") {
      updateBulkProgress(message.payload || {});
    }
    if (message?.type === "BULK_DOWNLOAD_SESSION") {
      renderBulkSession(message.payload || {});
    }
    return false;
  });
}

function wireMarketplaceSingleChoice() {
  const inputs = [elements.bulkMarketWb, elements.bulkMarketOzon].filter(Boolean);
  for (const input of inputs) {
    input.addEventListener("change", () => {
      if (!input.checked) {
        input.checked = true;
      }
      for (const other of inputs) {
        if (other !== input) other.checked = false;
      }
    });
  }
}
function renderBulkControls() {
  elements.bulkControls?.classList.remove("hidden");
}

function parseBulkSkus() {
  return [...new Set(String(elements.bulkSkus?.value || "")
    .split(/[\s,;]+/u)
    .map((value) => value.trim())
    .filter(Boolean))];
}

function getSelectedBulkMarketplaces() {
  const marketplaces = [];
  if (elements.bulkMarketWb?.checked) marketplaces.push("WB");
  if (elements.bulkMarketOzon?.checked) marketplaces.push("OZON");
  return marketplaces;
}

async function startBulkDownload() {
  if (state.bulkRunning) return;

  const skus = parseBulkSkus();
  const marketplaces = getSelectedBulkMarketplaces();

  if (!marketplaces.length) {
    showBulkValidationError("Выберите WB или OZON.");
    return;
  }

  if (!skus.length) {
    showBulkValidationError("Введите хотя бы один артикул.");
    return;
  }

  if (skus.length > BULK_INPUT_LIMIT) {
    showBulkValidationError("За один раз можно скачать до 100 артикулов.");
    return;
  }

  state.bulkRunning = true;
  elements.bulkStart.disabled = true;
  elements.bulkResults.innerHTML = "";
  await loadBulkOverlayCreative();
  showBulkOverlay("Подготавливаем список", 8, false, { tasks: buildOverlayTasksSnapshot() });

  for (const marketplace of marketplaces) {
    for (const sku of skus) {
      renderBulkResult({ marketplace, sku, status: "queued", message: "В очереди" });
    }
  }

  try {
    const response = await chrome.runtime.sendMessage({
      type: "START_BULK_MARKETPLACE_DOWNLOAD",
      payload: { marketplaces, skus, source: "popup_bulk" }
    });

    if (!response?.ok) {
      throw new Error(response?.error || "Не удалось запустить скачивание.");
    }

    showBulkOverlay("Скачивание завершено", 100, true, { phrase: "Готово — архивы скачаны.", tasks: buildOverlayTasksSnapshot() });
    setTimeout(() => hideBulkOverlay(), 1500);
  } catch (error) {
    showBulkOverlay("Ошибка скачивания", 100, true, { phrase: getBulkErrorMessage(error), tasks: buildOverlayTasksSnapshot() });
  } finally {
    state.bulkRunning = false;
    elements.bulkStart.disabled = false;
  }
}

async function stopBulkDownload() {
  await chrome.runtime.sendMessage({ type: "STOP_BULK_MARKETPLACE_DOWNLOAD" }).catch(() => null);
  showBulkOverlay("Останавливаем скачивание", 100, true, { phrase: "Останавливаем процесс безопасно…", tasks: buildOverlayTasksSnapshot() });
}

async function refreshBulkSession() {
  const response = await chrome.runtime.sendMessage({ type: "GET_BULK_MARKETPLACE_SESSION" }).catch(() => null);
  if (response?.ok) {
    renderBulkSession(response.session || {});
  }
}

function renderBulkSession(session) {
  const running = Boolean(session.running);
  state.bulkRunning = running;
  elements.bulkStart && (elements.bulkStart.disabled = running);
  elements.bulkSessionMini?.classList.toggle("hidden", !running);

  if (running) {
    const current = session.current || {};
    const label = current.sku ? `Скачивание ${current.marketplace || ""} ${current.sku}` : "Скачивание по списку";
    if (elements.bulkSessionMini) {
      elements.bulkSessionMini.textContent = label;
    }
    showBulkOverlay(label, session.progress || 20, false, { current: session.current, tasks: session.tasks || [] });
  } else if (elements.bulkSessionMini) {
    elements.bulkSessionMini.textContent = "";
  }

  for (const task of session.tasks || []) {
    renderBulkResult(task);
  }
}

function showBulkOverlay(message, progress = 20, stopped = false, details = {}) {
  elements.bulkOverlay?.classList.remove("hidden");
  if (elements.bulkOverlaySubtitle) {
    elements.bulkOverlaySubtitle.textContent = message || "Скачивание";
  }
  if (elements.bulkOverlayPhrase) {
    elements.bulkOverlayPhrase.textContent = details.phrase || getDownloadProgressPhrase(progress, details.current?.status);
  }
  if (elements.bulkOverlayLineBar) {
    elements.bulkOverlayLineBar.style.transform = `scaleX(${Math.max(0.05, Math.min(1, progress / 100))})`;
    elements.bulkOverlayLineBar.classList.toggle("is-complete", progress >= 100);
  }
  renderBulkOverlayTasks(details.tasks || buildOverlayTasksSnapshot(), details.current);
  if (elements.bulkStop) {
    elements.bulkStop.disabled = stopped;
  }
}

function hideBulkOverlay() {
  elements.bulkOverlay?.classList.add("hidden");
}

function showBulkValidationError(message) {
  showBulkOverlay("Проверьте список", 100, true, {
    phrase: message,
    tasks: buildOverlayTasksSnapshot()
  });
  setTimeout(() => hideBulkOverlay(), 1600);
}

function getBulkErrorMessage(error) {
  const message = String(error?.message || error || "");
  if (/vpn|failed to fetch|network|timeout|err_|не удалось открыть|не удалось скачать|site unavailable|couldn/i.test(message)) {
    return "Для скачивания отключите VPN";
  }
  return message || "Ошибка скачивания по списку.";
}

async function loadBulkOverlayCreative() {
  if (!elements.bulkOverlayCreative || !elements.bulkOverlayCreativeSlot) return;

  try {
    const config = await fetchRemoteConfig(ARTICLE_POPUP_PLACEMENT).catch(() => null) || await fetchRemoteConfig("download_progress").catch(() => null);
    const message = config?.message || null;
    if (!message) return;

    renderCreativeMessage(elements.bulkOverlayCreativeSlot, message);
    elements.bulkOverlayCreative.classList.add("has-admin-creative");
  } catch {
    // Keep fallback creative text.
  }
}

function renderCreativeMessage(slot, message) {
  const safeTitle = escapeHtml(message.title || "");
  const safeText = escapeHtml(message.text || "");
  const safeImageUrl = escapeHtml(message.imageUrl || "");
  const safeLinkHref = escapeAttributeValue(message.linkUrl || "");

  if (message.format === "image" && safeImageUrl) {
    slot.innerHTML = safeLinkHref
      ? `<a class="bulk-creative-image" href="${safeLinkHref}" target="_blank" rel="noreferrer"><img src="${safeImageUrl}" alt="${safeTitle || "Сообщение"}" /></a>`
      : `<div class="bulk-creative-image"><img src="${safeImageUrl}" alt="${safeTitle || "Сообщение"}" /></div>`;
    return;
  }

  slot.innerHTML = `
    <div class="bulk-creative-text">
      ${safeTitle ? `<strong>${safeTitle}</strong>` : ""}
      ${safeText ? `<p>${safeText}</p>` : ""}
    </div>
  `;
}

function escapeHtml(value) {
  return String(value || "")
    .replace(/&/g, "&amp;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;")
    .replace(/"/g, "&quot;")
    .replace(/'/g, "&#39;");
}

function escapeAttributeValue(value) {
  return String(value || "")
    .replace(/&/g, "&amp;")
    .replace(/"/g, "&quot;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;");
}
function updateBulkProgress(payload) {
  const { marketplace, sku, status, message, progress } = payload;
  if (status === "running") {
    const label = `Скачивание ${marketplace} ${sku}`;
    showBulkOverlay(label, progress || 35, false, { marketplace, sku, status, message, tasks: buildOverlayTasksSnapshot() });
  }
  if (status === "done") {
    showBulkOverlay(`Скачано ${marketplace} ${sku}`, progress || 90, false, { phrase: "Готово, переходим к следующему артикулу…", marketplace, sku, status, message, tasks: buildOverlayTasksSnapshot() });
  }
  if (status === "error") {
    showBulkOverlay(`Ошибка ${marketplace} ${sku}`, progress || 100, false, { phrase: message || "Не удалось скачать этот артикул.", marketplace, sku, status, message, tasks: buildOverlayTasksSnapshot() });
  }
  if (status === "stopped") {
    showBulkOverlay("Скачивание остановлено", 100, true, { phrase: "Процесс остановлен.", tasks: buildOverlayTasksSnapshot() });
    setTimeout(() => hideBulkOverlay(), 1200);
  }
  renderBulkResult({ marketplace, sku, status, message });
}

function renderBulkResult({ marketplace, sku, status, message }) {
  if (!elements.bulkResults || !marketplace || !sku) return;

  const key = `${marketplace}-${sku}`;
  let row = elements.bulkResults.querySelector(`[data-key="${CSS.escape(key)}"]`);
  if (!row) {
    row = document.createElement("div");
    row.className = "bulk-result-row";
    row.dataset.key = key;
    row.innerHTML = `
      <span class="bulk-result-icon">•</span>
      <span><strong></strong><span class="bulk-result-market"></span></span>
      <span class="bulk-result-message"></span>
    `;
    elements.bulkResults.append(row);
  }

  row.classList.toggle("is-running", status === "running");
  row.classList.toggle("is-done", status === "done");
  row.classList.toggle("is-error", status === "error");
  row.querySelector("strong").textContent = sku;
  row.querySelector(".bulk-result-market").textContent = ` ${marketplace}`;
  row.querySelector(".bulk-result-message").textContent = message || status || "";
  row.querySelector(".bulk-result-icon").textContent = status === "done" ? "✓" : status === "error" ? "!" : status === "running" ? "…" : "•";
}
function switchView(view, options = {}) {
  const allowed = new Set(["main", "seller-tools", "bulk-tool", "settings", "help", "design"]);
  const nextView = allowed.has(view) ? view : "main";
  state.currentView = nextView;
  elements.mainScreen?.classList.toggle("hidden", nextView !== "main");
  elements.sellerToolsScreen?.classList.toggle("hidden", nextView !== "seller-tools");
  elements.bulkToolScreen?.classList.toggle("hidden", nextView !== "bulk-tool");
  elements.settingsScreen?.classList.toggle("hidden", nextView !== "settings");
  elements.helpScreen?.classList.toggle("hidden", nextView !== "help");
  elements.designScreen?.classList.toggle('hidden',nextView !== 'design');
  if (options.persist !== false) {
    chrome.storage?.local?.set?.({ [LAST_POPUP_VIEW_KEY]: nextView });
  }
}

async function getLastPopupView() {
  try {
    const stored = await chrome.storage.local.get(LAST_POPUP_VIEW_KEY);
    const view = stored?.[LAST_POPUP_VIEW_KEY];
    return ["main", "seller-tools", "bulk-tool", "settings", "help", "design"].includes(view) ? view : "main";
  } catch {
    return "main";
  }
}

function getDownloadProgressPhrase(progress = 0, status = "") {
  if (status === "done" || progress >= 100) return "Готово — архив скачан.";
  if (status === "error") return "Не получилось скачать один из артикулов.";
  const index = Math.min(DOWNLOAD_PROGRESS_PHRASES.length - 1, Math.floor(Math.max(0, progress) / 22));
  return DOWNLOAD_PROGRESS_PHRASES[index];
}

function buildOverlayTasksSnapshot() {
  if (!elements.bulkResults) return [];
  return [...elements.bulkResults.querySelectorAll(".bulk-result-row")].map((row) => ({
    key: row.dataset.key || "",
    title: row.querySelector("strong")?.textContent || "",
    marketplace: row.querySelector(".bulk-result-market")?.textContent?.trim() || "",
    message: row.querySelector(".bulk-result-message")?.textContent || "",
    status: row.classList.contains("is-done") ? "done" : row.classList.contains("is-error") ? "error" : row.classList.contains("is-running") ? "running" : "queued"
  }));
}

function renderBulkOverlayTasks(tasks = [], current = null) {
  if (!elements.bulkOverlayTasks) return;
  const normalized = Array.isArray(tasks) ? tasks.slice(0, 50) : [];
  if (!normalized.length) {
    elements.bulkOverlayTasks.innerHTML = "";
    elements.bulkOverlayTasks.classList.add("hidden");
    return;
  }
  elements.bulkOverlayTasks.classList.remove("hidden");
  elements.bulkOverlayTasks.innerHTML = normalized.map((task) => {
    const marketplace = escapeHtml(task.marketplace || "");
    const sku = escapeHtml(task.sku || task.title || "");
    const message = escapeHtml(task.message || statusToText(task.status));
    const status = escapeHtml(task.status || "queued");
    const isCurrent = current?.sku && String(current.sku) === String(task.sku || task.title) && String(current.marketplace || "") === String(task.marketplace || "");
    return `<div class="bulk-overlay-task is-${status}${isCurrent ? " is-current" : ""}"><span></span><strong>${sku}</strong><em>${marketplace}</em><small>${message}</small></div>`;
  }).join("");
}

function statusToText(status) {
  if (status === "done") return "Скачано";
  if (status === "error") return "Ошибка";
  if (status === "running") return "Скачивание";
  if (status === "stopped") return "Остановлено";
  return "В очереди";
}

function applyConversionSettings(settings) {
  const defaultQuality = Math.round((settings.defaultQuality ?? settings.jpgQuality ?? 0.8) * 100);
  state.format = settings.defaultFormat || "jpg";
  state.quality = defaultQuality;

  if (elements.qualitySlider) {
    elements.qualitySlider.value = String(defaultQuality);
  }

  if (elements.qualityLabel) {
    elements.qualityLabel.textContent = `Качество: ${defaultQuality}%`;
  }

  if (elements.formatButtons) {
    renderFormatButtons(elements.formatButtons, state.format, (next) => {
      state.format = next;
    });
  }
}

function applySettingsForm(settings) {
  const quality = Math.round((settings.defaultQuality ?? settings.jpgQuality ?? 0.8) * 100);
  state.selectedFormat = settings.defaultFormat || "jpg";

  if (elements.saveFolder) {
    elements.saveFolder.value = settings.saveFolderPreset || "downloads";
  }

  if (elements.settingsQuality) {
    elements.settingsQuality.value = String(quality);
  }

  if (elements.settingsQualityLabel) {
    elements.settingsQualityLabel.textContent = `Качество по умолчанию: ${quality}%`;
  }

  if (elements.autoConvertOnDownload) {
    elements.autoConvertOnDownload.checked = Boolean(settings.autoConvertOnDownload);
  }

  if (elements.settingsFormatButtons) {
    renderFormatButtons(elements.settingsFormatButtons, state.selectedFormat, (next) => {
      state.selectedFormat = next;
    });
  }
}

function wireDropzone() {
  if (!elements.dropzone) {
    return;
  }

  elements.dropzone.addEventListener("dragover", (event) => {
    event.preventDefault();
    elements.dropzone.classList.add("is-active");
  });

  elements.dropzone.addEventListener("dragleave", () => {
    elements.dropzone.classList.remove("is-active");
  });

  elements.dropzone.addEventListener("drop", (event) => {
    event.preventDefault();
    elements.dropzone.classList.remove("is-active");
    addFiles(event.dataTransfer.files);
  });
}

function addFiles(fileList) {
  const accepted = [...fileList].filter((file) => file.type.startsWith("image/"));

  if (!accepted.length) {
    setStatus("Поддерживаются только изображения.", true);
    return;
  }

  state.files.push(...accepted.map((file) => ({
    id: crypto.randomUUID(),
    file
  })));

  updateFilesMeta();
  updateActionButtons();
  setStatus(`Добавлено файлов: ${state.files.length}.`);
}

function updateFilesMeta() {
  if (!elements.fileMeta) {
    return;
  }

  if (!state.files.length) {
    elements.fileMeta.textContent = "Файлы не выбраны";
    return;
  }

  const names = state.files.slice(0, 2).map((item) => item.file.name).join(", ");
  const tail = state.files.length > 2 ? ` и ещё ${state.files.length - 2}` : "";
  elements.fileMeta.textContent = `Выбрано: ${names}${tail}`;
}

function updateActionButtons() {
  if (!elements.convertAll) {
    return;
  }

  elements.convertAll.disabled = state.converting || state.files.length === 0;
}

async function convertAllFiles() {
  if (!state.files.length || state.converting) {
    return;
  }

  state.converting = true;
  updateActionButtons();

  try {
    const settings = await getSettings();

    for (const item of state.files) {
      await convertSingleFile(item.file, settings);
    }

    setStatus(`Готово: сконвертировано ${state.files.length} файл(ов).`);
    state.files = [];
    updateFilesMeta();
  } catch (error) {
    setStatus(error.message || "Ошибка конвертации.", true);
  } finally {
    state.converting = false;
    updateActionButtons();
  }
}

async function convertSingleFile(file, settings) {
  const quality = state.quality / 100;
  const format = state.format;

  setStatus(`Конвертация: ${file.name}...`);

  let result;
  if (requiresServerConversion(format)) {
    try {
      result = await convertViaServer(file, format, quality);
    } catch {
      throw new Error(`Не удалось выполнить ${format.toUpperCase()}-конвертацию. Проверьте доступность сервера.`);
    }
  } else {
    result = await convertBlob(file, format, quality);
  }

  const dataUrl = await blobToDataUrl(result.blob);
  const filename = replaceExtension(file.name, result.effectiveFormat || format);

  await chrome.downloads.download({
    url: dataUrl,
    filename,
    saveAs: false
  });

  chrome.runtime.sendMessage({
    type: "TRACK_EVENT",
    eventType: "conversion",
    payload: {
      fileName: file.name,
      targetFormat: format,
      actualFormat: result.effectiveFormat || format,
      via: "popup"
    }
  });

  if (result.note) {
    setStatus(result.note);
  }
}

function renderFormatButtons(container, selected, onChange) {
  container.innerHTML = "";

  for (const format of FORMATS) {
    const button = document.createElement("button");
    button.type = "button";
    button.className = `pill-btn${format === selected ? " active" : ""}`;
    button.dataset.value = format;
    button.textContent = format.toUpperCase();

    button.addEventListener("click", () => {
      for (const sibling of container.querySelectorAll(".pill-btn")) {
        sibling.classList.toggle("active", sibling === button);
      }
      onChange(format);
    });

    container.append(button);
  }
}

async function onSaveSettings() {
  const qualityRatio = Number(elements.settingsQuality?.value || 80) / 100;

  const settings = await saveSettings({
    defaultFormat: state.selectedFormat,
    defaultQuality: qualityRatio,
    saveFolderPreset: elements.saveFolder?.value || "downloads",
    jpgQuality: qualityRatio,
    pngQuality: qualityRatio,
    gifQuality: qualityRatio,
    tiffQuality: qualityRatio,
    autoConvertOnDownload: Boolean(elements.autoConvertOnDownload?.checked)
  });

  applySettingsForm(settings);
  applyConversionSettings(settings);
  setSaveStatus("Настройки сохранены.");
}

function setStatus(message, isError = false) {
  if (!elements.status) {
    return;
  }

  elements.status.textContent = message;
  elements.status.classList.toggle("error", Boolean(isError));
}

function setSaveStatus(message) {
  if (!elements.saveStatus) {
    return;
  }

  elements.saveStatus.textContent = message;
}

async function loadMessage() {
  try {
    await mountMessageSlot({
      panel: elements.messagePanel,
      slot: elements.messageSlot,
      placement: "extension_popup"
    });
  } catch (error) {
    if (elements.messagePanel) {
      elements.messagePanel.classList.remove("hidden");
    }

    if (elements.messageSlot) {
      elements.messageSlot.textContent = error.message || "Не удалось загрузить блок.";
    }
  }
}













