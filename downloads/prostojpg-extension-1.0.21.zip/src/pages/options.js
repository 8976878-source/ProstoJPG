import { mountMessageSlot } from "../lib/message-slot.js";
import { getSettings, saveSettings } from "../lib/settings.js";

const FORMATS = ["jpg", "png", "gif", "tiff"];

const elements = {
  saveFolder: document.getElementById("save-folder"),
  settingsQuality: document.getElementById("settings-quality"),
  settingsQualityLabel: document.getElementById("settings-quality-label"),
  settingsFormatButtons: document.getElementById("settings-format-buttons"),
  autoConvertOnDownload: document.getElementById("autoConvertOnDownload"),
  messagePanel: document.getElementById("message-panel"),
  messageSlot: document.getElementById("message-slot"),
  saveSettings: document.getElementById("save-settings"),
  cancelSettings: document.getElementById("cancel-settings"),
  saveStatus: document.getElementById("save-status")
};

const state = {
  selectedFormat: "jpg"
};

init();

async function init() {
  const settings = await getSettings();
  applySettings(settings);

  elements.settingsQuality.addEventListener("input", () => {
    elements.settingsQualityLabel.textContent = `Качество по умолчанию: ${elements.settingsQuality.value}%`;
  });

  elements.saveSettings.addEventListener("click", onSave);
  elements.cancelSettings.addEventListener("click", async () => {
    const latest = await getSettings();
    applySettings(latest);
    await loadMessage();
    setStatus("Изменения сброшены.");
  });

  await loadMessage();
}

function applySettings(settings) {
  const quality = Math.round((settings.defaultQuality ?? settings.jpgQuality ?? 0.8) * 100);
  state.selectedFormat = settings.defaultFormat || "jpg";

  elements.saveFolder.value = settings.saveFolderPreset || "downloads";
  elements.settingsQuality.value = String(quality);
  elements.settingsQualityLabel.textContent = `Качество по умолчанию: ${quality}%`;
  elements.autoConvertOnDownload.checked = Boolean(settings.autoConvertOnDownload);

  renderFormatButtons();
}

function renderFormatButtons() {
  elements.settingsFormatButtons.innerHTML = "";

  for (const format of FORMATS) {
    const button = document.createElement("button");
    button.type = "button";
    button.className = `pill-btn${format === state.selectedFormat ? " active" : ""}`;
    button.textContent = format.toUpperCase();

    button.addEventListener("click", () => {
      state.selectedFormat = format;
      for (const sibling of elements.settingsFormatButtons.querySelectorAll(".pill-btn")) {
        sibling.classList.toggle("active", sibling === button);
      }
    });

    elements.settingsFormatButtons.append(button);
  }
}

async function onSave() {
  const qualityRatio = Number(elements.settingsQuality.value) / 100;

  await saveSettings({
    defaultFormat: state.selectedFormat,
    defaultQuality: qualityRatio,
    saveFolderPreset: elements.saveFolder.value,
    jpgQuality: qualityRatio,
    pngQuality: qualityRatio,
    gifQuality: qualityRatio,
    tiffQuality: qualityRatio,
    autoConvertOnDownload: elements.autoConvertOnDownload.checked
  });

  await loadMessage();
  setStatus("Настройки сохранены.");
}

function setStatus(text) {
  elements.saveStatus.textContent = text;
}

async function loadMessage() {
  try {
    await mountMessageSlot({
      panel: elements.messagePanel,
      slot: elements.messageSlot,
      placement: "options"
    });
  } catch (error) {
    elements.messagePanel.classList.remove("hidden");
    elements.messageSlot.textContent = error.message || "Не удалось загрузить сообщение.";
  }
}
