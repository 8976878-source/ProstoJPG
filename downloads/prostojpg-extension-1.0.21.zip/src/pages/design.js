export function bindDesignScreen(switchView) {
  const byId = id => document.getElementById(id);
  const buttons = [...document.querySelectorAll('[data-design-mode]')];
  let mode = 2;
  byId('create-gpt-design').addEventListener('click',() => switchView('design'));
  byId('back-from-design').addEventListener('click',() => switchView('main'));
  byId('close-design-popup').addEventListener('click',() => window.close());
  function select(next) {
    mode = next;
    for (const button of buttons) {
      const selected = Number(button.dataset.designMode) === mode;
      button.classList.toggle('is-selected',selected);
      button.setAttribute('aria-pressed',String(selected));
    }
    byId('design-subject-row').classList.toggle('hidden',mode !== 3);
    byId('design-start').textContent = mode === 2 ? 'Создать похожие карточки' : 'Создать карточки с моим товаром';
  }
  for (const button of buttons) button.addEventListener('click',() => select(Number(button.dataset.designMode)));
  byId('design-form').addEventListener('submit', async event => {
    event.preventDefault();
    const status = byId('design-status');
    try {
      byId('design-start').disabled = true;
      status.textContent = 'Проверяем подключение к Codex…';
      let subjectDataUrl = null;
      if (mode === 3) {
        const file = byId('design-subject').files?.[0];
        if (!file || !['image/jpeg','image/png','image/webp','image/avif'].includes(file.type) || file.size > 20 * 1024 * 1024) {
          throw new Error('Добавьте фото товара в JPG, PNG, WEBP или AVIF, не больше 20 МБ.');
        }
        subjectDataUrl = await new Promise((resolve,reject) => { const reader = new FileReader(); reader.onload=() => resolve(reader.result); reader.onerror=() => reject(reader.error); reader.readAsDataURL(file); });
      }
      const response = await chrome.runtime.sendMessage({type:'PROSTOJPG_DESIGN_START',payload:{mode,
        marketplace:byId('design-marketplace').value,article:byId('design-article').value,subjectDataUrl}});
      if (!response?.ok) throw new Error(response?.error || 'Не удалось запустить создание карточек.');
      render(response.session);
    } catch(error) { status.textContent=error.message; byId('design-start').disabled=false; }
  });
  byId('design-stop').addEventListener('click',() => chrome.runtime.sendMessage({type:'PROSTOJPG_DESIGN_STOP'}));
  byId('design-open-result').addEventListener('click',async () => {
    const response = await chrome.runtime.sendMessage({type:'PROSTOJPG_DESIGN_OPEN_RESULT'});
    if (!response?.ok) byId('design-status').textContent=response?.error || 'Откройте архив по указанному пути.';
  });
  function render(session={}) {
    byId('design-status').textContent = session.message || '';
    byId('design-start').disabled = Boolean(session.running);
    byId('design-stop').classList.toggle('hidden',!session.running);
    byId('design-result').classList.toggle('hidden',!session.archive);
    byId('design-result-path').textContent=session.archive || '';
  }
  chrome.runtime.onMessage.addListener(message => { if (message?.type === 'PROSTOJPG_DESIGN_SESSION') render(message.session); });
  chrome.runtime.sendMessage({type:'PROSTOJPG_DESIGN_GET'}).then(response => render(response?.session));
  select(2);
}
