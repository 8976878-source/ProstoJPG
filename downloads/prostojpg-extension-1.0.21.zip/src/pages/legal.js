function sendMessage(message) {
  return new Promise((resolve, reject) => {
    try {
      chrome.runtime.sendMessage(message, (response) => {
        const lastError = chrome.runtime.lastError;
        if (lastError) {
          reject(new Error(lastError.message || "Runtime messaging failed"));
          return;
        }
        resolve(response);
      });
    } catch (error) {
      reject(error);
    }
  });
}

async function loadAgreement() {
  const contentNode = document.getElementById("content");
  const metaNode = document.getElementById("meta");

  try {
    const response = await sendMessage({ type: "GET_USER_AGREEMENT" });

    if (!response?.ok) {
      throw new Error(response?.error || "Не удалось получить соглашение");
    }

    const data = response.data || {};
    const value = String(data.value || "").trim();

    if (!value) {
      contentNode.textContent = "Пользовательское соглашение пока не заполнено.";
      contentNode.className = "status";
      metaNode.textContent = "";
      return;
    }

    contentNode.textContent = value;
    contentNode.className = "";

    if (data.updatedAt) {
      const dt = new Date(data.updatedAt);
      if (!Number.isNaN(dt.getTime())) {
        metaNode.textContent = `Последнее обновление: ${dt.toLocaleString("ru-RU")}`;
      } else {
        metaNode.textContent = "";
      }
    } else {
      metaNode.textContent = "";
    }
  } catch (error) {
    console.error("Failed to load user agreement", error);
    contentNode.textContent = `Не удалось загрузить пользовательское соглашение: ${error.message}`;
    contentNode.className = "error";
    metaNode.textContent = "";
  }
}

loadAgreement();