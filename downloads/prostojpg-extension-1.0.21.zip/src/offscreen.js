import { blobToDataUrl, convertBlob } from "./lib/conversion.js";

chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  if (message?.type !== "OFFSCREEN_CONVERT") {
    return false;
  }

  (async () => {
    const blob = message.sourceDataUrl
      ? await fetch(message.sourceDataUrl).then((response) => response.blob())
      : new Blob([message.buffer], { type: message.sourceMimeType || "image/webp" });
    const result = await convertBlob(blob, message.targetFormat, message.quality);
    const dataUrl = await blobToDataUrl(result.blob);

    sendResponse({
      ok: true,
      dataUrl,
      note: result.note,
      effectiveFormat: result.effectiveFormat
    });
  })().catch((error) => {
    sendResponse({
      ok: false,
      error: error.message
    });
  });

  return true;
});
