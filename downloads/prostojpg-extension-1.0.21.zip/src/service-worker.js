import { fetchRemoteConfig, postEvent } from "./lib/api.js";
import { blobToDataUrl, fetchAsBlob, replaceExtension, requiresServerConversion } from "./lib/conversion.js";
import { getInstallId, getSettings } from "./lib/settings.js";
import { createZipArchive } from "./lib/zip.js";
import { NativeCodexBridge, DESIGN_STORAGE_KEY, validateDesignRequest, isProductPhoto } from './lib/codex-bridge.js';

let designNative = null;
let designSession = {running:false,status:'idle',message:''};
let designCancelled = false;

const MENU_ITEMS = [
  { id: "save-as-jpg", title: "Сохранить как JPG", format: "jpg" },
  { id: "save-as-png", title: "Сохранить как PNG", format: "png" },
  { id: "save-as-gif", title: "Сохранить как GIF", format: "gif" },
  { id: "save-as-tiff", title: "Сохранить как TIFF", format: "tiff" }
];
const ROOT_MENU_ID = "prostojpg-root";
const GALLERY_MEDIA_MENU_ID = "download-gallery-media";
const DOWNLOAD_VIDEO_MENU_ID = "download-video";
const BADGE_SPINNER_FRAMES = ["◐", "◓", "◑", "◒"];

const FOLDER_PATH_PREFIX = {
  downloads: "",
  desktop: "Desktop/",
  documents: "Documents/",
  pictures: "Pictures/"
};

const autoConvertQueue = new Map();
const autoConvertProcessed = new Set();
const galleryProductContextByTabId = new Map();
const BULK_SESSION_STORAGE_KEY = "prostojpg.bulkDownloadSession";
const BULK_USAGE_STORAGE_KEY = "prostojpg.bulkDownloadUsage";
const BULK_INPUT_LIMIT = 100;
let bulkDownloadSession = { running: false, tasks: [], current: null, progress: 0 };
let bulkSessionRestored = false;
let bulkCancelRequested = false;
let bulkActiveTabId = null;
const lastGalleryDownloadIdByTabId = new Map();
let badgeSpinnerTimer = null;
let badgeSpinnerIndex = 0;

chrome.runtime.onInstalled.addListener(async ({ reason }) => {
  try {
    createContextMenus();
    await getInstallId();

    if (reason === "install") {
      try {
        await postEvent("install", {});
      } catch (error) {
        console.warn("Install event failed", error);
      }
    }
  } catch (error) {
    console.warn("onInstalled handler failed", error);
  }
});

chrome.runtime.onStartup.addListener(async () => {
  try {
    createContextMenus();
    await restoreBulkSession();
  } catch (error) {
    console.warn("onStartup handler failed", error);
  }
});

chrome.contextMenus.onClicked.addListener(async (info, tab) => {
  if (info.menuItemId === GALLERY_MEDIA_MENU_ID) {
    try {
      startBadgeSpinner();
      await downloadGalleryMediaArchive(info, tab);
      setActionBadge("done");
    } catch (error) {
      await notifyGalleryDownloadError(tab?.id, "Не удалось скачать фото и видео. Откройте карточку товара и попробуйте ещё раз.");
      setActionBadge("error");
      console.error("Gallery media download failed", error);
    }
    return;
  }

  if (info.menuItemId === DOWNLOAD_VIDEO_MENU_ID) {
    try {
      startBadgeSpinner();
      await downloadContextVideo(info);
      setActionBadge("done");
    } catch (error) {
      setActionBadge("error");
      console.error("Context video download failed", error);
    }
    return;
  }

  const item = MENU_ITEMS.find((entry) => entry.id === info.menuItemId);
  if (!item || !info.srcUrl) {
    return;
  }

  try {
    await convertRemoteImageAndDownload(info.srcUrl, item.format, undefined, "context-menu", true, {
      referrer: info.pageUrl || ""
    });
  } catch (error) {
    console.error("Context conversion failed", error);
  }
});

chrome.downloads.onCreated.addListener(async (downloadItem) => {
  const settings = await getSettings();

  if (!settings.autoConvertOnDownload) {
    return;
  }

  const remoteUrl = resolveDownloadUrl(downloadItem);
  if (!remoteUrl || !isHttpUrl(remoteUrl) || !hasWebpHint(downloadItem)) {
    return;
  }

  autoConvertQueue.set(downloadItem.id, {
    url: remoteUrl,
    filename: deriveDownloadFileName(downloadItem.filename, "image.webp")
  });
});

chrome.downloads.onChanged.addListener(async (delta) => {
  if (autoConvertProcessed.has(delta.id)) {
    return;
  }

  let queued = autoConvertQueue.get(delta.id);
  if (!queued && /\.webp(?:$|\?)/i.test(delta.filename?.current || "")) {
    const settings = await getSettings();
    if (!settings.autoConvertOnDownload) {
      return;
    }

    const downloadItem = await searchDownloadById(delta.id);
    const remoteUrl = resolveDownloadUrl(downloadItem);
    if (remoteUrl && isHttpUrl(remoteUrl)) {
      queued = {
        url: remoteUrl,
        filename: deriveDownloadFileName(delta.filename.current, "image.webp")
      };
      autoConvertQueue.set(delta.id, queued);
    }
  }

  if (!queued && delta.state?.current === "complete") {
    const settings = await getSettings();
    if (!settings.autoConvertOnDownload) {
      return;
    }

    const downloadItem = await searchDownloadById(delta.id);
    const remoteUrl = resolveDownloadUrl(downloadItem);
    if (!remoteUrl || !isHttpUrl(remoteUrl)) {
      return;
    }

    let isWebp = hasWebpHint(downloadItem);
    if (!isWebp) {
      const contentType = await detectRemoteContentType(remoteUrl);
      isWebp = /image\/webp/i.test(contentType);
    }

    if (isWebp) {
      queued = {
        url: remoteUrl,
        filename: deriveDownloadFileName(downloadItem.filename, "image.webp")
      };
      autoConvertQueue.set(delta.id, queued);
    }
  }

  if (delta.state?.current === "interrupted") {
    autoConvertQueue.delete(delta.id);
    return;
  }

  if (!queued || delta.state?.current !== "complete") {
    return;
  }

  try {
    const completedItem = await searchDownloadById(delta.id);
    const completedUrl = resolveDownloadUrl(completedItem);
    if (completedUrl && isHttpUrl(completedUrl)) {
      queued.url = completedUrl;
    }
    if (completedItem?.filename) {
      queued.filename = deriveDownloadFileName(completedItem.filename, queued.filename || "image.webp");
    }

    await convertRemoteImageAndDownload(queued.url, "jpg", queued.filename, "auto-download", false, {
      preferServer: true
    });
    markAutoConvertProcessed(delta.id);
    await cleanupOriginalDownload(delta.id);
  } catch (error) {
    console.warn("Auto conversion skipped", error);
  } finally {
    autoConvertQueue.delete(delta.id);
  }
});

chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  if (String(message?.type || '').startsWith('PROSTOJPG_DESIGN_')) {
    if (sender?.url !== chrome.runtime.getURL('src/pages/popup.html')) {
      sendResponse({ok:false,error:'Design requests are only accepted from the extension popup.'});
      return false;
    }
    handleDesignMessage(message).then(sendResponse).catch(error => sendResponse({ok:false,error:error.message}));
    return true;
  }
  if (message?.type === "GALLERY_PRODUCT_CONTEXT_UPDATED") {
    const tabId = sender?.tab?.id;
    if (tabId && message.productInfo?.sku) {
      galleryProductContextByTabId.set(tabId, message.productInfo);
      updateGalleryMediaMenu(message.productInfo);
    }
    sendResponse({ ok: true });
    return false;
  }

  if (message?.type === "OPEN_DOWNLOADS_PAGE") {
    const downloadId = sender?.tab?.id ? lastGalleryDownloadIdByTabId.get(sender.tab.id) : null;
    if (downloadId) {
      chrome.downloads.show(downloadId);
      sendResponse({ ok: true });
      return false;
    }

    chrome.downloads.showDefaultFolder();
    sendResponse({ ok: true });
    return false;
  }

  if (message?.type === "FETCH_REMOTE_CONFIG") {
    fetchRemoteConfig(message.placement || "popup")
      .then((config) => sendResponse({ ok: true, config }))
      .catch((error) => sendResponse({ ok: false, error: error.message }));
    return true;
  }

  if (message?.type === "FETCH_REMOTE_CONFIG_FOR_PAGE") {
    const pageUrl = message.url || sender?.tab?.url || "";
    if (!isAllowedConfigPageUrl(pageUrl, message.placement || "popup")) {
      sendResponse({ ok: true, config: { messages: [] } });
      return false;
    }

    fetchRemoteConfigForPage({
      placement: message.placement || "popup",
      url: pageUrl,
      host: message.host || safeGetHost(pageUrl)
    })
      .then((config) => sendResponse({ ok: true, config }))
      .catch((error) => sendResponse({ ok: false, error: error.message }));
    return true;
  }

  if (message?.type === "TRACK_EVENT") {
    postEvent(message.eventType, message.payload || {})
      .then((response) => sendResponse({ ok: true, response }))
      .catch((error) => sendResponse({ ok: false, error: error.message }));
    return true;
  }

  if (message?.type === "GET_USER_AGREEMENT") {
    fetchUserAgreement()
      .then((response) => sendResponse({ ok: true, data: response }))
      .catch((error) => sendResponse({ ok: false, error: error.message }));
    return true;
  }


  if (message?.type === "START_BULK_MARKETPLACE_DOWNLOAD") {
    startBulkMarketplaceDownload(message.payload || {})
      .then((response) => sendResponse({ ok: true, response }))
      .catch((error) => sendResponse({ ok: false, error: error.message }));
    return true;
  }

  if (message?.type === "GET_BULK_MARKETPLACE_SESSION") {
    restoreBulkSession().then(() => sendResponse({ ok: true, session: bulkDownloadSession }));
    return true;
  }

  if (message?.type === "STOP_BULK_MARKETPLACE_DOWNLOAD") {
    stopBulkMarketplaceDownload().then(() => sendResponse({ ok: true })).catch((error) => sendResponse({ ok: false, error: error.message }));
    return true;
  }
  if (message?.type === "PING") {
    sendResponse({ ok: true, pong: true });
    return false;
  }

  return false;
});

function createContextMenus() {
  chrome.contextMenus.removeAll(() => {
    chrome.contextMenus.create({
      id: ROOT_MENU_ID,
      title: "ПростоJPG",
      contexts: ["page", "image", "video", "link"]
    });

    for (const item of MENU_ITEMS) {
      chrome.contextMenus.create({
        id: item.id,
        title: item.title,
        parentId: ROOT_MENU_ID,
        contexts: ["image"]
      });
    }

    chrome.contextMenus.create({
      id: DOWNLOAD_VIDEO_MENU_ID,
      title: "Скачать видео",
      parentId: ROOT_MENU_ID,
      contexts: ["video", "link"],
      targetUrlPatterns: ["*://*/*.mp4*", "*://*/*.webm*", "*://*/*.mov*"]
    });

    chrome.contextMenus.create({
      id: GALLERY_MEDIA_MENU_ID,
      title: "Скачать все фото и видео",
      parentId: ROOT_MENU_ID,
      contexts: ["page", "image", "video", "link"],
      documentUrlPatterns: ["https://www.wildberries.ru/*", "https://www.ozon.ru/*"]
    });
  });
}
if (chrome.contextMenus.onShown) {
  chrome.contextMenus.onShown.addListener(async (info, tab) => {
    const productInfo =
      getProductInfoFromUrl(info.pageUrl || tab?.url || "") ||
      getStoredGalleryProductContext(tab?.id) ||
      (await getGalleryProductContext(tab?.id));
    updateGalleryMediaMenu(productInfo);
  });
}

function updateGalleryMediaMenu(productInfo) {
  const hasSku = Boolean(productInfo?.sku);
  const title = "Скачать все фото и видео";

  chrome.contextMenus.update(GALLERY_MEDIA_MENU_ID, { title, enabled: hasSku }, () => {
    if (chrome.runtime.lastError) {
      return;
    }
  });
}
function startBadgeSpinner() {
  stopBadgeSpinner();
  badgeSpinnerIndex = 0;
  chrome.action.setBadgeBackgroundColor({ color: "#2563eb" });
  chrome.action.setBadgeTextColor?.({ color: "#ffffff" });
  chrome.action.setBadgeText({ text: BADGE_SPINNER_FRAMES[badgeSpinnerIndex] });
  badgeSpinnerTimer = setInterval(() => {
    badgeSpinnerIndex = (badgeSpinnerIndex + 1) % BADGE_SPINNER_FRAMES.length;
    chrome.action.setBadgeText({ text: BADGE_SPINNER_FRAMES[badgeSpinnerIndex] });
  }, 120);
}

function stopBadgeSpinner() {
  if (badgeSpinnerTimer) {
    clearInterval(badgeSpinnerTimer);
    badgeSpinnerTimer = null;
  }
}

function setActionBadge(state) {
  stopBadgeSpinner();
  const config = {
    done: { text: "OK", color: "#16a34a", clearAfterMs: 4000 },
    error: { text: "ERR", color: "#dc2626", clearAfterMs: 7000 }
  }[state];

  if (!config) {
    chrome.action.setBadgeText({ text: "" });
    return;
  }

  chrome.action.setBadgeBackgroundColor({ color: config.color });
  chrome.action.setBadgeTextColor?.({ color: "#ffffff" });
  chrome.action.setBadgeText({ text: config.text });
  setTimeout(() => chrome.action.setBadgeText({ text: "" }), config.clearAfterMs);
}

async function ensureOffscreenDocument() {
  const offscreenUrl = chrome.runtime.getURL("src/offscreen.html");

  try {
    if (chrome.runtime.getContexts) {
      const contexts = await chrome.runtime.getContexts({
        contextTypes: ["OFFSCREEN_DOCUMENT"],
        documentUrls: [offscreenUrl]
      });

      if (contexts.length > 0) {
        return;
      }
    }
  } catch (error) {
    console.warn("getContexts failed", error);
  }

  try {
    await chrome.offscreen.createDocument({
      url: "src/offscreen.html",
      reasons: ["BLOBS"],
      justification: "Convert images in a MV3 offscreen document."
    });
  } catch (error) {
    const message = String(error?.message || "");
    if (!/Only a single offscreen document may be created|already exists/i.test(message)) {
      throw error;
    }
  }
}

async function resetOffscreenDocument() {
  try {
    await chrome.offscreen.closeDocument();
  } catch {
    // ignore
  }

  await ensureOffscreenDocument();
}

async function convertRemoteImageAndDownload(url, targetFormat, originalFilename, via = "context-menu", saveAs = true, options = {}) {
  const settings = await getSettings();
  const fallbackQuality = settings.defaultQuality ?? 1;
  const qualityMap = {
    jpg: settings.jpgQuality ?? fallbackQuality,
    png: settings.pngQuality ?? fallbackQuality,
    gif: settings.gifQuality ?? fallbackQuality,
    tiff: settings.tiffQuality ?? fallbackQuality
  };

  const fallbackNameFromUrl = new URL(url).pathname.split("/").pop() || "image.webp";
  const sourceName = deriveDownloadFileName(originalFilename, fallbackNameFromUrl);
  const blob = await fetchAsBlob(url, {
    referrer: options.referrer || ""
  });
  const quality = qualityMap[targetFormat] ?? fallbackQuality;
  const forceServer = Boolean(options?.preferServer) || requiresServerConversion(targetFormat);

  let conversion;
  if (forceServer) {
    try {
      conversion = await convertUsingServer(blob, targetFormat, quality, sourceName);
    } catch (error) {
      if (requiresServerConversion(targetFormat)) {
        throw error;
      }
      conversion = await convertUsingOffscreen(blob, targetFormat, quality);
    }
  } else {
    try {
      conversion = await convertUsingOffscreen(blob, targetFormat, quality);
    } catch (error) {
      if (!settings.apiBaseUrl) {
        throw error;
      }
      conversion = await convertUsingServer(blob, targetFormat, quality, sourceName);
    }
  }

  const convertedName = replaceExtension(sourceName, conversion.effectiveFormat || targetFormat);
  const targetFilename = applyFolderPreset(convertedName, settings.saveFolderPreset);

  await chrome.downloads.download({
    url: conversion.dataUrl,
    filename: targetFilename,
    saveAs
  });

  await postEvent("conversion", {
    targetFormat,
    actualFormat: conversion.effectiveFormat || targetFormat,
    sourceUrl: url,
    via
  }).catch(() => null);
}

async function downloadContextVideo(info) {
  const sourceUrl = info.srcUrl || info.linkUrl || "";
  if (!sourceUrl || !/\.(mp4|webm|mov)(?:$|[?#])/iu.test(sourceUrl)) {
    throw new Error("Ссылка на видео не найдена");
  }

  const parsed = new URL(sourceUrl);
  const fallbackName = parsed.pathname.split("/").pop() || "video.mp4";
  const extension = extensionFromMedia(sourceUrl, "");
  const filename = replaceExtension(deriveDownloadFileName("", fallbackName), extension);

  await chrome.downloads.download({
    url: sourceUrl,
    filename,
    saveAs: false
  });
}

async function convertUsingOffscreen(blob, targetFormat, quality) {
  const sourceDataUrl = await blobToDataUrl(blob);

  await ensureOffscreenDocument();

  try {
    const response = await sendRuntimeMessageSafe({
      type: "OFFSCREEN_CONVERT",
      sourceDataUrl,
      sourceMimeType: blob.type,
      targetFormat,
      quality
    });

    if (!response?.ok) {
      throw new Error(response?.error || "Image conversion failed");
    }

    return response;
  } catch (error) {
    const message = String(error?.message || "");
    if (/Receiving end does not exist|Could not establish connection/i.test(message)) {
      await resetOffscreenDocument();

      const retryResponse = await sendRuntimeMessageSafe({
        type: "OFFSCREEN_CONVERT",
        sourceDataUrl,
        sourceMimeType: blob.type,
        targetFormat,
        quality
      });

      if (!retryResponse?.ok) {
        throw new Error(retryResponse?.error || "Image conversion failed");
      }

      return retryResponse;
    }

    throw error;
  }
}
async function convertUsingServer(blob, targetFormat, quality, filename) {
  const settings = await getSettings();
  if (!settings.apiBaseUrl) {
    throw new Error("API base URL is not configured");
  }

  const formData = new FormData();
  formData.append("file", new File([blob], filename, { type: blob.type || "image/webp" }));
  formData.append("targetFormat", targetFormat);
  formData.append("quality", String(quality));

  const headers = {};
  if (settings.apiToken) {
    headers.Authorization = `Bearer ${settings.apiToken}`;
  }

  const response = await fetch(`${settings.apiBaseUrl}/api/public/convert`, {
    method: "POST",
    headers,
    body: formData
  });

  if (!response.ok) {
    throw new Error(`Server conversion unavailable: ${response.status}`);
  }

  const outputBlob = await response.blob();
  const dataUrl = await blobToDataUrl(outputBlob);

  return {
    ok: true,
    dataUrl,
    effectiveFormat: (response.headers.get("x-output-format") || targetFormat).replace("jpeg", "jpg"),
    note: response.headers.get("x-conversion-note") || ""
  };
}

async function fetchRemoteConfigForPage({ placement, host }) {
  const settings = await getSettings();
  if (!settings.apiBaseUrl) {
    throw new Error("API base URL is not configured");
  }

  const installId = await getInstallId();
  const browser = detectBrowserFromUA();

  const params = new URLSearchParams({
    installId,
    browser,
    placement,
    host: String(host || "")
  });

  const headers = {};
  if (settings.apiToken) {
    headers.Authorization = `Bearer ${settings.apiToken}`;
  }

  const response = await fetch(`${settings.apiBaseUrl}/api/public/config?${params.toString()}`, {
    method: "GET",
    headers
  });

  if (!response.ok) {
    throw new Error(`Config request failed: ${response.status}`);
  }

  return response.json();
}

async function fetchUserAgreement() {
  const settings = await getSettings();
  if (!settings.apiBaseUrl) {
    throw new Error("API base URL is not configured");
  }

  const headers = {};
  if (settings.apiToken) {
    headers.Authorization = `Bearer ${settings.apiToken}`;
  }

  const response = await fetch(`${settings.apiBaseUrl}/api/public/user-agreement`, {
    method: "GET",
    headers
  });

  if (!response.ok) {
    throw new Error(`Agreement request failed: ${response.status}`);
  }

  return response.json();
}

function detectBrowserFromUA() {
  const ua = navigator.userAgent.toLowerCase();
  if (ua.includes("yabrowser") || ua.includes("yandex")) {
    return "yandex";
  }
  if (ua.includes("edg/") || ua.includes("chrome/")) {
    return "chrome";
  }
  return "unknown";
}

function safeGetHost(rawUrl) {
  try {
    return new URL(rawUrl).host;
  } catch {
    return "";
  }
}

function isAllowedSellerUrl(rawUrl) {
  try {
    const url = new URL(rawUrl);
    return (
      url.protocol === "https:" &&
      (url.hostname === "seller.ozon.ru" || url.hostname === "seller.wildberries.ru")
    );
  } catch {
    return false;
  }
}

function isAllowedConfigPageUrl(rawUrl, placement) {
  if (isAllowedSellerUrl(rawUrl)) {
    return true;
  }

  if (!["extension_popup", "download_popup", "download_progress"].includes(String(placement || ""))) {
    return false;
  }

  try {
    const url = new URL(rawUrl);
    return (
      url.protocol === "https:" &&
      (url.hostname === "www.ozon.ru" || url.hostname === "www.wildberries.ru")
    );
  } catch {
    return false;
  }
}

function applyFolderPreset(filename, preset) {
  const prefix = FOLDER_PATH_PREFIX[preset] || "";
  return `${prefix}${filename}`;
}

function markAutoConvertProcessed(downloadId) {
  autoConvertProcessed.add(downloadId);
  setTimeout(() => autoConvertProcessed.delete(downloadId), 5 * 60 * 1000);
}

function searchDownloadById(downloadId) {
  return new Promise((resolve) => {
    try {
      chrome.downloads.search({ id: downloadId }, (items) => {
        resolve(items?.[0] || null);
      });
    } catch {
      resolve(null);
    }
  });
}

async function cleanupOriginalDownload(downloadId) {
  await new Promise((resolve) => {
    try {
      chrome.downloads.removeFile(downloadId, () => resolve());
    } catch {
      resolve();
    }
  });

  await new Promise((resolve) => {
    try {
      chrome.downloads.erase({ id: downloadId }, () => resolve());
    } catch {
      resolve();
    }
  });
}

function hasWebpHint(downloadItem) {
  return (
    /\.webp(?:$|[?#])/i.test(downloadItem?.filename || "") ||
    /\.webp(?:$|[?#])/i.test(downloadItem?.url || "") ||
    /\.webp(?:$|[?#])/i.test(downloadItem?.finalUrl || "") ||
    /image\/webp/i.test(downloadItem?.mime || "")
  );
}

function resolveDownloadUrl(downloadItem) {
  return String(downloadItem?.finalUrl || downloadItem?.url || "");
}

function isHttpUrl(url) {
  return /^https?:/i.test(String(url || ""));
}

function deriveDownloadFileName(filename, fallback = "image.webp") {
  const source = String(filename || "").trim();
  if (!source) {
    return fallback;
  }

  const normalized = source.replace(/\\/g, "/");
  const baseName = normalized.split("/").pop();
  return baseName || fallback;
}

function getProductInfoFromUrl(rawUrl) {
  try {
    const url = new URL(rawUrl);
    const host = url.hostname.toLowerCase();

    if (host === "www.wildberries.ru") {
      const sku = url.pathname.match(/\/catalog\/(\d+)\//iu)?.[1];
      return sku ? { marketplace: "WB", sku } : null;
    }

    if (host === "www.ozon.ru") {
      if (!/\/product\//iu.test(url.pathname)) {
        return null;
      }

      const skuParam = url.searchParams.get("sku");
      if (skuParam && /^\d+$/u.test(skuParam)) {
        return { marketplace: "OZON", sku: skuParam };
      }

      const sku = url.pathname.match(/-(\d+)\/?$/iu)?.[1];
      return sku ? { marketplace: "OZON", sku } : null;
    }
  } catch {
    return null;
  }

  return null;
}

function getStoredGalleryProductContext(tabId) {
  return tabId ? galleryProductContextByTabId.get(tabId) || null : null;
}


async function startBulkMarketplaceDownload(payload) {
  if (designSession.running) throw new Error('Дождитесь создания карточек или остановите его.');
  await restoreBulkSession();
  if (bulkDownloadSession.running) {
    throw new Error("Скачивание уже идёт.");
  }

  const marketplaces = sanitizeBulkMarketplaces(payload.marketplaces);
  const skus = sanitizeBulkSkus(payload.skus);

  if (!marketplaces.length) {
    throw new Error("Выберите маркетплейс.");
  }

  if (!skus.length) {
    throw new Error("Введите артикулы.");
  }

  if (skus.length > BULK_INPUT_LIMIT) {
    throw new Error("За один раз можно скачать до 100 артикулов.");
  }

  bulkCancelRequested = false;
  await postBulkDownloadEvent("bulk_download_start", {
    source: payload.source || "popup_bulk",
    marketplaces,
    skuCount: skus.length,
    taskCount: marketplaces.length * skus.length
  });

  const tasks = [];
  for (const marketplace of marketplaces) {
    for (const sku of skus) {
      tasks.push({ marketplace, sku, status: "queued", message: "В очереди" });
    }
  }

  await updateBulkSession({ running: true, tasks, current: null, progress: 5 });
  const results = [];

  for (let index = 0; index < tasks.length; index += 1) {
    const task = tasks[index];
    if (bulkCancelRequested) {
      await updateBulkTask(task, "stopped", "Остановлено", Math.round((index / Math.max(tasks.length, 1)) * 100));
      break;
    }

    const progress = Math.round((index / Math.max(tasks.length, 1)) * 82) + 8;
    await updateBulkTask(task, "running", "Скачивание", progress);
    await sendBulkProgress({ ...task, status: "running", message: "Скачивание", progress });

    try {
      await downloadBulkMarketplaceItem(task.marketplace, task.sku);
      await recordBulkDownloadUsage(task.marketplace, task.sku);
      results.push({ ...task, ok: true });
      await updateBulkTask(task, "done", "Скачано", Math.min(96, progress + 8));
      await sendBulkProgress({ ...task, status: "done", message: "Скачано", progress: Math.min(96, progress + 8) });
    } catch (error) {
      if (bulkCancelRequested) {
        await updateBulkTask(task, "stopped", "Остановлено", 100);
        await sendBulkProgress({ ...task, status: "stopped", message: "Остановлено", progress: 100 });
        break;
      }
      results.push({ ...task, ok: false, error: error.message });
      await updateBulkTask(task, "error", "Ошибка", Math.min(96, progress + 8));
      await sendBulkProgress({ ...task, status: "error", message: "Ошибка", progress: Math.min(96, progress + 8) });
    }

    await wait(500);
  }

  await updateBulkSession({ running: false, current: null, progress: 100 });
  await postBulkDownloadEvent("bulk_download_finish", {
    source: payload.source || "popup_bulk",
    marketplaces,
    skuCount: skus.length,
    taskCount: tasks.length,
    successCount: results.filter((item) => item.ok).length,
    errorCount: results.filter((item) => !item.ok).length,
    successByMarketplace: countBulkResultsByMarketplace(results, true),
    errorByMarketplace: countBulkResultsByMarketplace(results, false),
    stopped: bulkCancelRequested
  });
  if (bulkCancelRequested) {
    await sendBulkProgress({ status: "stopped", message: "Остановлено", progress: 100 });
  }
  setTimeout(() => {
    bulkDownloadSession = { running: false, tasks: [], current: null, progress: 0 };
  }, 1500);

  return { results };
}

async function recordBulkDownloadUsage(marketplace, sku) {
  const usage = await getBulkUsage();
  usage.dayCount += 1;
  usage.monthCount += 1;
  await chrome.storage.local.set({ [BULK_USAGE_STORAGE_KEY]: usage });
  await postBulkDownloadEvent("bulk_download_item", {
    marketplace,
    sku,
    email: usage.email || "",
    day: usage.day,
    month: usage.month
  });
}

function countBulkResultsByMarketplace(results, ok) {
  return results
    .filter((item) => Boolean(item.ok) === ok)
    .reduce((summary, item) => {
      const key = String(item.marketplace || "UNKNOWN").toUpperCase();
      summary[key] = (summary[key] || 0) + 1;
      return summary;
    }, {});
}

async function getBulkUsage() {
  const now = new Date();
  const day = now.toISOString().slice(0, 10);
  const month = now.toISOString().slice(0, 7);
  const stored = await chrome.storage.local.get(BULK_USAGE_STORAGE_KEY);
  const usage = stored?.[BULK_USAGE_STORAGE_KEY] || {};
  return {
    email: String(usage.email || ""),
    day,
    month,
    dayCount: usage.day === day ? Number(usage.dayCount || 0) : 0,
    monthCount: usage.month === month ? Number(usage.monthCount || 0) : 0
  };
}

async function stopBulkMarketplaceDownload() {
  bulkCancelRequested = true;
  if (bulkActiveTabId) {
    try {
      await chrome.tabs.remove(bulkActiveTabId);
    } catch {
      // Ignore already closed tab.
    }
  }
  await updateBulkSession({ running: false, current: null, progress: 100 });
  await sendBulkProgress({ status: "stopped", message: "Остановлено", progress: 100 });
}

async function updateBulkSession(patch) {
  bulkDownloadSession = { ...bulkDownloadSession, ...patch };
  await chrome.storage.local.set({ [BULK_SESSION_STORAGE_KEY]: bulkDownloadSession });
  await broadcastBulkSession();
}

async function restoreBulkSession() {
  if (bulkSessionRestored) return;
  bulkSessionRestored = true;
  const stored = await chrome.storage.local.get(BULK_SESSION_STORAGE_KEY);
  const session = stored?.[BULK_SESSION_STORAGE_KEY];
  if (session && typeof session === "object") {
    bulkDownloadSession = { ...bulkDownloadSession, ...session, running: false, current: null };
    await chrome.storage.local.set({ [BULK_SESSION_STORAGE_KEY]: bulkDownloadSession });
  }
}

async function updateBulkTask(task, status, message, progress) {
  const tasks = bulkDownloadSession.tasks.map((item) => (
    item.marketplace === task.marketplace && item.sku === task.sku
      ? { ...item, status, message }
      : item
  ));
  await updateBulkSession({ tasks, current: { ...task, status, message }, progress });
}

async function broadcastBulkSession() {
  try {
    await chrome.runtime.sendMessage({ type: "BULK_DOWNLOAD_SESSION", payload: bulkDownloadSession });
  } catch {
    // Popup may be closed; the in-memory session stays available.
  }
}
function sanitizeBulkMarketplaces(value) {
  const allowed = new Set(["WB", "OZON"]);
  return [...new Set((Array.isArray(value) ? value : [])
    .map((item) => String(item || "").toUpperCase())
    .filter((item) => allowed.has(item)))];
}

function sanitizeBulkSkus(value) {
  return [...new Set((Array.isArray(value) ? value : [])
    .map((item) => String(item || "").trim())
    .filter(Boolean))];
}

function getBulkDownloadErrorMessage(error) {
  const message = String(error?.message || error || "");
  if (/failed to fetch|network|timeout|err_|unable to load|не удалось открыть|не удалось скачать|couldn/i.test(message)) {
    return "Для скачивания отключите VPN";
  }
  return message || "Ошибка";
}

async function postBulkDownloadEvent(type, payload = {}) {
  try {
    await postEvent(type, payload);
  } catch {
    // Statistics must never block downloads.
  }
}

async function sendBulkProgress(payload) {
  try {
    await chrome.runtime.sendMessage({
      type: "BULK_DOWNLOAD_PROGRESS",
      payload
    });
  } catch {
    // Popup may be closed; downloading should continue.
  }
}

async function downloadBulkMarketplaceItem(marketplace, sku) {
  if (bulkCancelRequested) {
    throw new Error("Остановлено");
  }

  const tab = await chrome.tabs.create({
    url: buildBulkProductUrl(marketplace, sku),
    active: false
  });

  bulkActiveTabId = tab.id;

  try {
    await waitForBulkProductPage(tab.id, marketplace, sku);
    if (bulkCancelRequested) {
      throw new Error("Остановлено");
    }
    await downloadGalleryMediaArchive({ pageUrl: await getTabUrl(tab.id) }, { id: tab.id, url: await getTabUrl(tab.id) });
  } finally {
    if (bulkActiveTabId === tab.id) {
      bulkActiveTabId = null;
    }
    if (tab?.id) {
      try {
        await chrome.tabs.remove(tab.id);
      } catch {
        // Ignore already closed tab.
      }
    }
  }
}

function buildBulkProductUrl(marketplace, sku) {
  const safeSku = encodeURIComponent(String(sku));
  if (marketplace === "WB") {
    return `https://www.wildberries.ru/catalog/${safeSku}/detail.aspx?targetUrl=MI`;
  }


  return `https://www.ozon.ru/search/?text=${safeSku}`;
}

async function waitForBulkProductPage(tabId, marketplace, sku) {
  const startedAt = Date.now();
  let lastUrl = "";
  while (Date.now() - startedAt < 45000) {
    if (bulkCancelRequested) {
      throw new Error("Остановлено");
    }
    const tab = await chrome.tabs.get(tabId);
    lastUrl = tab.url || lastUrl;

    if (marketplace === "WB" && /\/catalog\/\d+\/detail\.aspx/iu.test(lastUrl) && await waitForBulkGalleryReady(tabId, sku)) {
      return;
    }

    if (marketplace === "OZON") {
      if (/\/product\//iu.test(lastUrl) && lastUrl.includes(String(sku)) && await waitForBulkGalleryReady(tabId, sku)) {
        return;
      }

      await openOzonProductFromSearch(tabId, sku);
    }

    await wait(1000);
  }

  throw new Error(`Не удалось открыть карточку ${marketplace} ${sku}`);
}

async function waitForBulkGalleryReady(tabId, sku) {
  try {
    let response = await sendTabMessageSafe(tabId, { type: "GET_GALLERY_PAGE_READY", sku: String(sku) });
    if (response?.ready) return true;
    await injectGalleryMediaCollector(tabId);
    response = await sendTabMessageSafe(tabId, { type: "GET_GALLERY_PAGE_READY", sku: String(sku) });
    return Boolean(response?.ready);
  } catch {
    return false;
  }
}

async function openOzonProductFromSearch(tabId, sku) {
  try {
    const [result] = await chrome.scripting.executeScript({
      target: { tabId },
      func: (targetSku) => {
        const links = [...document.querySelectorAll('a[href*="/product/"]')]
          .map((link) => new URL(link.href, location.href).href)
          .filter((href) => href.includes(String(targetSku)));
        const url = links[0] || "";
        if (url) {
          location.href = url;
        }
        return url;
      },
      args: [String(sku)]
    });
    return result?.result || "";
  } catch {
    return "";
  }
}

async function getTabUrl(tabId) {
  const tab = await chrome.tabs.get(tabId);
  return tab.url || "";
}

async function downloadGalleryMediaArchive(info, tab) {
  const startedAt = Date.now();
  const tabId = tab?.id;
  if (!tabId) {
    throw new Error("Вкладка товара не найдена");
  }

  const pageUrl = info.pageUrl || tab?.url || "";
  const productInfo =
    getProductInfoFromUrl(pageUrl) ||
    getStoredGalleryProductContext(tabId) ||
    (await getGalleryProductContext(tabId));

  if (!productInfo?.sku) {
    throw new Error("Артикул товара не найден");
  }

  await notifyGalleryDownloadProgress(tabId, "Скачиваем в хорошем качестве, потерпите.", 18);
  const collected = await collectGalleryMediaWithRetry(tabId, productInfo.marketplace);
  await notifyGalleryDownloadProgress(tabId, "Скачиваем фото и видео из галереи…", 32);
  const marketplace = collected.marketplace || productInfo.marketplace;
  const sku = collected.sku || productInfo.sku;
  const media = Array.isArray(collected.media) ? collected.media : [];
  if (media.some((item) => /\.m3u8(?:$|[?#])/iu.test(String(item?.url || "")))) {
    throw new Error("Видео товара передаётся потоково и не может быть сохранено в MP4 без серверной конвертации.");
  }
  const prefix = marketplace === "WB" ? "WB" : marketplace === "OZON" ? "OZON" : "PRODUCT";
  const entries = [];
  const failedMedia = [];
  const seenNames = new Set();

  for (const item of media) {
    try {
      const blob = await fetchAsBlob(item.url, {
        referrer: pageUrl,
        credentials: "omit"
      });
      const isVideo = item.type === "video";
      if (!isVideo) {
        await notifyGalleryDownloadProgress(tabId, "Конвертируем всё в понятный формат JPG и MP4…", 32 + Math.round(((entries.length + 1) / media.length) * 56));
      }
      const outputBlob = isVideo ? blob : await convertImageBlobToJpg(blob, item.url);
      const extension = isVideo ? extensionFromMedia(item.url, blob.type) : "jpg";
      entries.push({
        name: uniqueFileName(`${prefix}_${sanitizeFileName(sku)}_${String(entries.length + 1).padStart(2, "0")}-${isVideo ? "video" : "photo"}.${extension}`, seenNames),
        blob: outputBlob
      });
    } catch (error) {
      console.warn("Gallery media skipped", item.url, error);
      failedMedia.push(item.url);
    }
  }

  if (!entries.length) {
    throw new Error("Не удалось скачать фото или видео из галереи");
  }

  if (failedMedia.length) {
    throw new Error(`Не удалось скачать ${failedMedia.length} из ${media.length} файлов товара`);
  }

  await notifyGalleryDownloadProgress(tabId, "Еще чуть-чуть… Собираем аккуратный архив.", 92);
  const archive = await createZipArchive(entries);
  const archiveUrl = await blobToDataUrl(archive);

  const downloadId = await chrome.downloads.download({
    url: archiveUrl,
    filename: `${prefix}_${sanitizeFileName(sku)}.zip`,
    saveAs: false
  });
  lastGalleryDownloadIdByTabId.set(tabId, downloadId);

  await wait(Math.max(0, 5000 - (Date.now() - startedAt)));
  await notifyGalleryDownloadReady(tabId);
}

async function getGalleryProductContext(tabId) {
  if (!tabId) {
    return null;
  }

  try {
    const response = await sendTabMessageSafe(tabId, { type: "GET_GALLERY_PRODUCT_CONTEXT" });
    return response?.productInfo || null;
  } catch {
    await injectGalleryMediaCollector(tabId);
    const response = await sendTabMessageSafe(tabId, { type: "GET_GALLERY_PRODUCT_CONTEXT" });
    return response?.productInfo || null;
  }
}

async function collectGalleryMediaWithRetry(tabId, marketplace = "", options = {}) {
  let lastError = null;
  const attempts = marketplace === "WB" ? 3 : 2;
  for (let attempt = 1; attempt <= attempts; attempt += 1) {
    try {
      const result = await collectGalleryMedia(tabId, options);
      if (Array.isArray(result?.media) && result.media.length) {
        return result;
      }
      lastError = new Error("Медиа товара не найдены");
    } catch (error) {
      lastError = error;
    }
    await wait(900 * attempt);
  }
  throw lastError || new Error("Не удалось собрать галерею");
}

async function collectGalleryMedia(tabId, options = {}) {
  try {
    const response = await sendTabMessageSafe(tabId, { type: "COLLECT_GALLERY_MEDIA", requireComplete: options.requireComplete === true });
    if (!response?.ok) {
      throw new Error(response?.error || "Не удалось собрать галерею");
    }
    return response.result || {};
  } catch {
    await injectGalleryMediaCollector(tabId);
    const response = await sendTabMessageSafe(tabId, { type: "COLLECT_GALLERY_MEDIA", requireComplete: options.requireComplete === true });
    if (!response?.ok) {
      throw new Error(response?.error || "Не удалось собрать галерею");
    }
    return response.result || {};
  }
}

async function hideGalleryDownloadPopup(tabId, delayMs = 0) {
  if (!tabId) {
    return;
  }

  try {
    await sendTabMessageSafe(tabId, {
      type: "HIDE_GALLERY_DOWNLOAD_POPUP",
      delayMs
    });
  } catch {
    // Popup cleanup is best-effort.
  }
}

async function notifyGalleryDownloadProgress(tabId, text, progress) {
  if (!tabId) {
    return;
  }

  try {
    await sendTabMessageSafe(tabId, {
      type: "GALLERY_DOWNLOAD_PROGRESS",
      text,
      progress
    });
  } catch {
    // Popup update is best-effort.
  }
}

async function notifyGalleryDownloadReady(tabId, delayMs = 0) {
  if (!tabId) {
    return;
  }

  try {
    await sendTabMessageSafe(tabId, {
      type: "GALLERY_DOWNLOAD_READY",
      delayMs
    });
  } catch {
    // Popup update is best-effort.
  }
}

async function notifyGalleryDownloadError(tabId, errorText, delayMs = 0) {
  if (!tabId) {
    return;
  }

  try {
    await sendTabMessageSafe(tabId, {
      type: "GALLERY_DOWNLOAD_ERROR",
      errorText,
      delayMs
    });
  } catch {
    // Popup update is best-effort.
  }
}

async function injectGalleryMediaCollector(tabId) {
  await chrome.scripting.executeScript({
    target: { tabId },
    files: ["src/lib/gallery-media-collector.js"]
  });
}

async function convertImageBlobToJpg(blob, sourceUrl = "") {
  try {
    const response = await convertUsingOffscreen(blob, "jpg", 0.95);
    const dataUrl = response.dataUrl || "";
    const fetchResponse = await fetch(dataUrl);
    return fetchResponse.blob();
  } catch (error) {
    const sourceName = deriveDownloadFileNameFromUrl(sourceUrl, "photo.webp");
    const response = await convertUsingServer(blob, "jpg", 0.95, sourceName);
    const fetchResponse = await fetch(response.dataUrl);
    return fetchResponse.blob();
  }
}

function deriveDownloadFileNameFromUrl(rawUrl, fallback) {
  try {
    return new URL(rawUrl).pathname.split("/").pop() || fallback;
  } catch {
    return fallback;
  }
}

function extensionFromMedia(url, mimeType) {
  try {
    const match = new URL(url).pathname.match(/\.([a-z0-9]{2,5})(?:$|[?.])/iu);
    if (match) {
      const extension = match[1].toLowerCase().replace("jpeg", "jpg");
      if (["mp4", "webm", "mov"].includes(extension)) return extension;
    }
  } catch {
    // Ignore invalid URL.
  }

  if (/webm/i.test(mimeType)) return "webm";
  if (/mov/i.test(mimeType)) return "mov";
  return "mp4";
}

function sanitizeFileName(value) {
  return String(value || "sku")
    .replace(/[\\/:*?"<>|]+/gu, "_")
    .replace(/\s+/gu, "_")
    .slice(0, 80);
}

function uniqueFileName(name, seenNames) {
  if (!seenNames.has(name)) {
    seenNames.add(name);
    return name;
  }

  const dotIndex = name.lastIndexOf(".");
  const base = dotIndex > -1 ? name.slice(0, dotIndex) : name;
  const extension = dotIndex > -1 ? name.slice(dotIndex) : "";
  let index = 2;
  let candidate = `${base}-${index}${extension}`;

  while (seenNames.has(candidate)) {
    index += 1;
    candidate = `${base}-${index}${extension}`;
  }

  seenNames.add(candidate);
  return candidate;
}

function sendTabMessageSafe(tabId, message) {
  return new Promise((resolve, reject) => {
    try {
      chrome.tabs.sendMessage(tabId, message, (response) => {
        const lastError = chrome.runtime.lastError;
        if (lastError) {
          reject(new Error(lastError.message || "Tab messaging failed"));
          return;
        }
        resolve(response);
      });
    } catch (error) {
      reject(error);
    }
  });
}

function wait(ms) {
  return new Promise((resolve) => setTimeout(resolve, ms));
}

async function detectRemoteContentType(url) {
  try {
    const response = await fetch(url, {
      method: "HEAD",
      credentials: "include"
    });

    if (response.ok) {
      return String(response.headers.get("content-type") || "");
    }
  } catch {
    return "";
  }

  return "";
}

function sendRuntimeMessageSafe(message) {
  return new Promise((resolve, reject) => {
    try {
      chrome.runtime.sendMessage(message, (response) => {
        const lastError = chrome.runtime.lastError;
        if (lastError) {
          reject(new Error(lastError.message || "Runtime messaging failed"));
          return;
        }
        resolve(response);
      });
    } catch (error) {
      reject(error);
    }
  });
}

async function updateDesignSession(patch) {
  designSession = {...designSession,...patch};
  await chrome.storage.local.set({[DESIGN_STORAGE_KEY]:designSession});
  try { await chrome.runtime.sendMessage({type:'PROSTOJPG_DESIGN_SESSION',session:designSession}); } catch { /* Popup can be closed while the job runs. */ }
}

async function handleDesignMessage(message) {
  if (message.type === 'PROSTOJPG_DESIGN_GET') {
    if (!designNative) {
      const saved = (await chrome.storage.local.get(DESIGN_STORAGE_KEY))[DESIGN_STORAGE_KEY];
      if (saved) designSession = {...saved,running:false,...(saved.running ? {status:'error',message:'Связь с Codex прервалась. Исходники сохранены; запустите создание повторно.'} : {})};
    }
    return {ok:true,session:designSession};
  }
  if (message.type === 'PROSTOJPG_DESIGN_STOP') {
    designCancelled = true;
    if (designNative && !designNative.closed) await designNative.request('cancel');
    await updateDesignSession({message:'Останавливаем создание. Исходники сохранятся.'});
    return {ok:true};
  }
  if (message.type === 'PROSTOJPG_DESIGN_OPEN_RESULT') {
    if (!designNative || designNative.closed) throw new Error('Соединение закрыто. Откройте архив по показанному пути.');
    await designNative.request('open_result'); return {ok:true};
  }
  if (message.type !== 'PROSTOJPG_DESIGN_START') throw new Error('Unknown design action.');
  if (designSession.running || bulkDownloadSession.running) throw new Error('Дождитесь текущей обработки или остановите её.');
  const request = validateDesignRequest(message.payload);
  designCancelled = false;
  designSession = {running:true,status:'connecting',message:'Подключаемся к Codex…',mode:request.mode,marketplace:request.marketplace,article:request.article};
  await updateDesignSession({});
  runDesignRequest(request).catch(error => updateDesignSession({running:false,status:'error',message:error.message}));
  return {ok:true,session:designSession};
}

function assertDesignNotCancelled() {
  if (designCancelled) throw new Error('Создание карточек остановлено.');
}

async function runDesignRequest(request) {
  if (designNative && !designNative.closed) designNative.close();
  let native;
  native = new NativeCodexBridge(event => {
    if (designNative !== native) return;
    if (event.status === 'disconnected' && !designSession.running) return;
    updateDesignSession({...event,running:!['done','error','disconnected'].includes(event.status)}).catch(console.error);
  });
  designNative = native;
  let ready = await native.request('ping');
  if (ready.login_required) {
    const login = await native.request('login');
    const loginUrl = new URL(login.auth_url);
    if (loginUrl.protocol !== 'https:' || !['auth.openai.com','chatgpt.com'].includes(loginUrl.hostname)) throw new Error('Некорректный адрес входа Codex.');
    await chrome.tabs.create({url:loginUrl.href,active:true});
    await updateDesignSession({status:'login',message:'Войдите в Codex через ChatGPT в открытой вкладке. После входа создание продолжится.'});
    const deadline = Date.now() + 5 * 60 * 1000;
    do {
      assertDesignNotCancelled();
      await wait(2000);
      ready = await native.request('ping');
    } while (!ready.ready && Date.now() < deadline);
  }
  if (!ready.ready) throw new Error('Вход в Codex не завершён. Повторите создание после входа.');
  assertDesignNotCancelled();
  await updateDesignSession({status:'collecting',message:'Открываем карточку товара в вашем браузере…'});
  const matches = await chrome.tabs.query({url:request.marketplace === 'WB' ? 'https://www.wildberries.ru/catalog/*/detail.aspx*' : 'https://www.ozon.ru/product/*'});
  const existing = matches.find(tab => {
    const product = getProductInfoFromUrl(tab.url || '');
    return product?.marketplace === request.marketplace && String(product.sku) === request.article;
  });
  const tab = existing || await chrome.tabs.create({url:buildBulkProductUrl(request.marketplace,request.article),active:true});
  let transferred = false;
  try {
    // Reuse the extension's normal browser-based gallery handling, without
    // invoking chrome.downloads.download or assembling a browser ZIP.
    bulkCancelRequested = false;
    await waitForBulkProductPage(tab.id,request.marketplace,request.article);
    assertDesignNotCancelled();
    const pageUrl = await getTabUrl(tab.id);
    const product = getProductInfoFromUrl(pageUrl);
    if (product?.marketplace !== request.marketplace || String(product.sku) !== request.article) throw new Error('Открылась карточка с другим артикулом. Откройте нужную карточку и повторите.');
    const gallery = await collectGalleryMediaWithRetry(tab.id,request.marketplace,{requireComplete:true});
    if (String(gallery.sku) !== request.article || gallery.marketplace !== request.marketplace) throw new Error('Галерея не соответствует выбранному артикулу.');
    if (gallery.complete !== true || !Number.isInteger(gallery.expected_media_count) || gallery.visited_media_count !== gallery.expected_media_count) throw new Error('Полный набор фото не подтверждён. Откройте первое фото галереи и повторите создание.');
    const photos = (gallery.media || []).filter(item => item.type === 'image');
    if (!photos.length || photos.length > 100 || photos.some(item => !isProductPhoto(item.url,request.marketplace,request.article))) throw new Error('Не удалось получить корректный полный набор фото товара.');
    const files = [];
    let bytes = 0;
    for (let index=0; index<photos.length; index++) {
      assertDesignNotCancelled();
      await updateDesignSession({status:'downloading',message:`Скачиваем исходное фото ${index+1} из ${photos.length}`});
      const blob = await fetchAsBlob(photos[index].url,{referrer:pageUrl,credentials:'omit'});
      bytes += blob.size;
      if (!blob.size || blob.size > 100 * 1024 * 1024 || bytes > 256 * 1024 * 1024) throw new Error('Набор фото слишком велик для передачи. Максимум 100 МБ на фото и 256 МБ на набор.');
      files.push({role:'source',blob});
    }
    if (request.mode === 3) {
      const subject = await fetch(request.subjectDataUrl).then(response => response.blob());
      files.push({role:'subject',blob:subject});
    }
    const begun = await native.request('begin',{mode:request.mode,marketplace:request.marketplace,article:request.article,
      files:files.map(file => ({role:file.role,size:file.blob.size}))});
    await updateDesignSession({status:'uploading',job_id:begun.job_id,message:'Передаём фото локальному Codex…'});
    for (let index=0; index<files.length; index++) { assertDesignNotCancelled(); await native.upload(index,files[index].blob); }
    assertDesignNotCancelled();
    await native.request('commit');
    transferred = true;
    // The open native port keeps the service worker alive while Codex generates.
  } finally {
    await hideGalleryDownloadPopup(tab.id);
    if (!existing && transferred) { try { await chrome.tabs.remove(tab.id); } catch { /* User may already have closed it. */ } }
  }
}
















